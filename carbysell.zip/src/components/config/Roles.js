
export const onlyAdmin = {
    Admin : "ADMIN"
}

export const onlyDealer = {
    Dealer:"DEALER"
}

export const onlyInspector = {
    Inspector:"INSPECTOR"
}

export const onlySeller = {
    SalesPerson: "SALESPERSON"
}